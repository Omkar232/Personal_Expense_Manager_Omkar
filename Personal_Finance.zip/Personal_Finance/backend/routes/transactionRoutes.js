const express = require("express");
const authMiddleware = require("../middleware/authMiddleware");
const {
  addTransaction,
  getTransactions,
  deleteTransaction,
  deleteAllTransactions, // Import the new function
} = require("../controllers/transactionController");

const router = express.Router();

// Protected Routes
router.get("/", authMiddleware, getTransactions);
router.post("/", authMiddleware, addTransaction);
router.delete("/:id", authMiddleware, deleteTransaction); // Route for deleting a single transaction
router.delete("/", authMiddleware, deleteAllTransactions); // Route for deleting all transactions

module.exports = router;
const Transaction = require("../models/Transaction");

// Add a new transaction
const addTransaction = async (req, res) => {
  const { name, amount, type } = req.body;

  try {
    const newTransaction = new Transaction({
      userId: req.user.id,
      name,
      amount,
      type,
    });

    await newTransaction.save();
    res.json(newTransaction);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server Error");
  }
};

// Get all transactions for a user
const getTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find({ userId: req.user.id });
    res.json(transactions);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Server Error");
  }
};

// Delete a single transaction
const deleteTransaction = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" });
    }

    // Check if the transaction belongs to the logged-in user
    if (transaction.userId.toString() !== req.user.id) {
      return res.status(401).json({ message: "Not authorized" });
    }

    await Transaction.deleteOne({ _id: req.params.id }); // Use deleteOne instead of remove
    res.json({ message: "Transaction deleted" });
  } catch (error) {
    console.error("Error deleting transaction:", error.message);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// Delete all transactions for the logged-in user
const deleteAllTransactions = async (req, res) => {
  try {
    // Delete all transactions belonging to the logged-in user
    await Transaction.deleteMany({ userId: req.user.id }); // Delete all transactions for the user
    res.json({ message: "All transactions deleted" });
  } catch (error) {
    console.error("Error deleting all transactions:", error.message);
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// Export the functions
module.exports = { addTransaction, getTransactions, deleteTransaction, deleteAllTransactions };
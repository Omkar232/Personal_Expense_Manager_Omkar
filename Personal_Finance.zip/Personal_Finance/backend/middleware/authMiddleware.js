const jwt = require("jsonwebtoken");

// Example route to fetch user profile
// router.get("/profile", authMiddleware, async (req, res) => {
//   try {
//     const user = await User.findById(req.user.id).select("-password"); // Exclude password
//     res.json(user);
//   } catch (error) {
//     console.error("Error fetching user profile:", error.message);
//     res.status(500).json({ message: "Server Error" });
//   }
// });

const authMiddleware = (req, res, next) => {
  // Get token from header
  const token = req.header("x-auth-token");

  // Check if token exists
  if (!token) {
    return res.status(401).json({ message: "No token, authorization denied" });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user;
    next();
  } catch (error) {
    res.status(401).json({ message: "Token is not valid" });
  }
};

module.exports = authMiddleware;
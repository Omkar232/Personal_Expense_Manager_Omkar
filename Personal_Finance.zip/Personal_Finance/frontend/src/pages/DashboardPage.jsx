import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import DashHeader from "../components/DashHeader";
import Footer from "../components/Footer";

//import { Link } from "react-router-dom";



const DashboardPage = () => {
  const [transactions, setTransactions] = useState([]);
  const [transactionName, setTransactionName] = useState("");
  const [transactionAmount, setTransactionAmount] = useState("");
  const [transactionType, setTransactionType] = useState("income");
  //const [userProfile, setUserProfile] = useState(null); // State for user profile
  const navigate = useNavigate();

  // Check if the user is authenticated
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login"); // Redirect to login if not authenticated
    }
  }, [navigate]);

  // Fetch transactions from the backend
  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get("http://localhost:5000/api/transactions", {
          headers: {
            "x-auth-token": token,
          },
        });
        setTransactions(response.data);
      } catch (error) {
        console.error("Error fetching transactions:", error);

        // If the token is invalid or expired, redirect to login
        if (error.response?.status === 401) {
          localStorage.removeItem("token"); // Remove invalid token
          navigate("/login"); // Redirect to login
        }
      }
    };

    fetchTransactions();
  }, [navigate]);

  // Add a new transaction
  const handleAddTransaction = async (e) => {
    e.preventDefault();

    try {
      const token = localStorage.getItem("token");
      const response = await axios.post(
        "http://localhost:5000/api/transactions",
        {
          name: transactionName,
          amount: transactionAmount,
          type: transactionType,
        },
        {
          headers: {
            "x-auth-token": token,
          },
        }
      );

      setTransactions([...transactions, response.data]);
      setTransactionName("");
      setTransactionAmount("");
    } catch (error) {
      console.error("Error adding transaction:", error);

      // If the token is invalid or expired, redirect to login
      if (error.response?.status === 401) {
        localStorage.removeItem("token"); // Remove invalid token
        navigate("/login"); // Redirect to login
      }
    }
  };

  // Delete a single transaction
  const handleDeleteTransaction = async (id) => {
    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/api/transactions/${id}`, {
        headers: {
          "x-auth-token": token,
        },
      });

      // Remove the transaction from the local state
      setTransactions(transactions.filter((transaction) => transaction._id !== id));
    } catch (error) {
      console.error("Error deleting transaction:", error);

      // If the token is invalid or expired, redirect to login
      if (error.response?.status === 401) {
        localStorage.removeItem("token"); // Remove invalid token
        navigate("/login"); // Redirect to login
      }
    }
  };

  // Delete all transactions
  const handleResetTransactions = async () => {
    try {
      const token = localStorage.getItem("token");
  
      // Confirm before deleting all transactions
      const confirmReset = window.confirm("Are you sure you want to delete all transactions? This action cannot be undone.");
      if (!confirmReset) return; // Exit if the user cancels
  
      // Send DELETE request to delete all transactions
      await axios.delete("http://localhost:5000/api/transactions", {
        headers: {
          "x-auth-token": token,
        },
      });
  
      // Clear the transactions in the local state
      setTransactions([]);
      alert("All transactions have been deleted."); // Notify the user
    } catch (error) {
      console.error("Error deleting all transactions:", error);
  
      // If the token is invalid or expired, redirect to login
      if (error.response?.status === 401) {
        localStorage.removeItem("token"); // Remove invalid token
        navigate("/login"); // Redirect to login
      } else {
        alert("Failed to delete all transactions: " + (error.response?.data?.message || error.message));
      }
    }
  };

  return (
    <div className="dashboard-page">
      <DashHeader/>
        
      
      <main className="dashboard-container">
        <h2>Dashboard</h2>
       
        {/* Summary Boxes */}
        <div className="summary-boxes">
          <div className="summary-box income-box">
            <h3>Total Income</h3>
            <p>${transactions
              .filter((t) => t.type === "income")
              .reduce((sum, t) => sum + t.amount, 0)
              .toFixed(2)}</p>
          </div>
          <div className="summary-box expense-box">
            <h3>Total Expenses</h3>
            <p>${transactions
              .filter((t) => t.type === "expense")
              .reduce((sum, t) => sum + t.amount, 0)
              .toFixed(2)}</p>
          </div>
          <div className="summary-box balance-box">
            <h3>Balance</h3>
            <p>${(
              transactions
                .filter((t) => t.type === "income")
                .reduce((sum, t) => sum + t.amount, 0) -
              transactions
                .filter((t) => t.type === "expense")
                .reduce((sum, t) => sum + t.amount, 0)
            ).toFixed(2)}</p>
          </div>
        </div>

        {/* Add Transaction Form */}
        <form className="transaction-form" onSubmit={handleAddTransaction}>
          <div className="form-group">
            <label>Transaction Name:</label>
            <input
              type="text"
              value={transactionName}
              onChange={(e) => setTransactionName(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Amount:</label>
            <input
              type="number"
              value={transactionAmount}
              onChange={(e) => setTransactionAmount(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Type:</label>
            <select
              value={transactionType}
              onChange={(e) => setTransactionType(e.target.value)}
            >
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>
          </div>
          <button type="submit" className="add-button">
            Add Transaction
          </button>
        </form>

        {/* Transactions List */}
        <div className="transactions-list">
          <h3>Transactions</h3>
          {transactions.length === 0 ? (
            <p>No transactions added yet.</p>
          ) : (
            <ul>
              {transactions.map((transaction) => (
                <li key={transaction._id}>
                  <span>{transaction.name}</span>
                  <span
                    className={
                      transaction.type === "income" ? "income" : "expense"
                    }
                  >
                    {transaction.type === "income" ? "+" : "-"}$
                    {transaction.amount.toFixed(2)}
                  </span>
                  <button
                    className="delete-button"
                    onClick={() => handleDeleteTransaction(transaction._id)}
                  >
                    Delete
                  </button>
                </li>
              ))}
            </ul>
          )}
          {/* Reset Button */}
          {transactions.length > 0 && (
            <button
              className="reset-button"
              onClick={handleResetTransactions}
            >
              Reset All Transactions
            </button>
          )}
        </div>

      </main>
      <Footer />
    </div>
  );
};

export default DashboardPage;
import React from "react";
import { Link, useNavigate } from "react-router-dom"; // Import Link and useNavigate
import logo from "../assets/logo.jpg"; // Adjust the path to your logo


const Header = () => {
    
  const navigate = useNavigate();

  const handleLogout = () => {
    // Remove the token from localStorage
    localStorage.removeItem("token");

    // Redirect to the login page
    navigate("/login");
  };

  return (
    <header className="header">
        <div className="logo-container">
                <img src={logo} alt="Personal Finance Manager Logo" className="logo" />
                <h1>Personal Finance Manager</h1>
        </div>
      <nav>
              <Link to="/">Home</Link>
              
              
              <Link to="/logout">Logout</Link>
            </nav>
    </header>
  );
};

export default Header;